#scores datasets not in mastertable alone or against the mastertable

#ARG1: file name
#ARG2: against mastertable (M) or alone (A)
#ARG3: format: with experimental details (Full) or just prospector output (Simple)
#ARG4: carryover remove (1) or not (0) 

prospectorfile=$1

if [ -z "$prospectorfile" ]  
then
	echo
	echo
	echo -e "\t**********************************************************"
	echo -e "\t*  Welcome to KroGan Lab scoring pipeline - KGL	    *"
	echo -e "\t*  written by Peter and Natali (Nevan Krogan Lab)        *"
	echo -e "\t*               May 2011                                 *"
	echo -e "\t**********************************************************"
	echo
	echo
echo "Correct Usage: bash scoring_script.sh <prospector_input> M/A F/S 1/0"
	echo "<prospector_input>"
	echo -e "\texample: vanessa/Magnetic_IP_3A_3B_3C_MS_results.txt"
	echo
	echo
	echo
	exit
else 
	echo
	echo -e "\t**********************************************************"
	echo -e "\t*  Welcome to KroGan Lab scoring pipeline - KGL	    *"
	echo -e "\t*  written by Peter and Natali (Nevan Krogan Lab)        *"
	echo -e "\t*               May 2011                                 *"
	echo -e "\t**********************************************************"
	echo
	echo
fi

scorebg=$2 #1 to score against mastertable or alone
format=$3 #F/S

###Score against mastertable with full format

if [ "$scorebg" = "M" ]
then
	if [ "$format" = "F" ]
	then

	#Merge Mastertable with individual dataset

	cat 2013_Mar14_MasterTable.txt "$prospectorfile"  > "$prospectorfile"_merged.txt
	prospectorfile="$prospectorfile"_merged.txt

	elif [ "$format" = "S" ] 
	then
#Create the latest mastertable in the right format

	awk -F "\t" '{print $3"\t"$9"\t"$21"\t"$22"\t"$23"\t"$24"\t"$25"\t"$26"\t"$27"\t"$28"\t"$29"\t"$30}' MasterTable_Oct292012/2012_Oct29_Mastertable_hIP95.txt.nocarryover > Mastertable.txt	
	cat Mastertable.txt "$prospectorfile"  > "$prospectorfile"_merged.txt
	prospectorfile="$prospectorfile"_merged.txt

	fi
fi

###############
######CARRYOVER
###############

carryover=$4 #1 to remove carryover
if [ $carryover -eq "1" ]
then
	perl carryover_removal_comprehensive.pl "$prospectorfile" "$format" > "$prospectorfile".carryover
	prospectorfile="$prospectorfile".carryover
fi


#######################
######CONVERT TO MATRIX
#######################

perl convert_to_matrix_format_comprehensive.pl "$prospectorfile" "$format" > "$prospectorfile"_input.txt
python FileCheck.py "$prospectorfile"_input.txt


###########
######SCORE
###########

######MiST no training/using HIV metrics

python MiST/MiST.py "$prospectorfile"_input.txt "$prospectorfile"_notraining 0 0 

######MiST with training

#python MiST/MiST_invert.py "$prospectorfile"_input.txt "$prospectorfile"_training 0 1
python MiST/MiST.py "$prospectorfile"_input.txt "$prospectorfile"_training 0 1

######CompASS

echo -e "Running compass"
python GetComppass.py "$prospectorfile"_input.txt > "$prospectorfile"_compass
echo -e "Done with compass"

######SAINT
#saint/saint-spc-noctrl-matrix "$prospectorfile"_input.txt "$prospectorfile"_out_saint 1500 10000 0.9



############
######OUTPUT
############

#Convert all the scores to a final table with Entrez Gene Symbols and IDs
perl convert_out_to_final_comprehensive.pl "$prospectorfile" "$format" | awk -F "\t" '$1' > "$prospectorfile"_scoring.txt
echo -e "Scores can be found in ""$prospectorfile"_scoring.txt
tr -d "\015" < "$prospectorfile"_scoring.txt > x ; mv x "$prospectorfile"_scoring.txt

